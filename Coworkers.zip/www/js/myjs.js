var timerInterval = 0;
var timeCurrent = 0;
var date_start = 0;
var date_end = 0;
var old_date = 0;
var month = ['Su','Mn','Tu','We','Th','Fr','Sa'];
var reason = [0,'חג לאומי','חופשה', 'חופשת מחלה'];
var chatInterval='';
var scroll = 0;
 
function timer(elapsed_seconds){
			clearInterval(timerInterval);
			timerInterval = setInterval(function() {
			  elapsed_seconds = elapsed_seconds + 1;
			  getTime = get_elapsed_time_string(elapsed_seconds);
			  $('.circle .text').text(getTime['current']);
			  $('.circle .text').data('time',getTime['totalSeconds']);
			  timeCurrent = getTime['totalSeconds'];
			  $('.play').addClass('stop').removeClass('play');
			 // setTime();
			}, 1000);		
}	

function get_elapsed_time_string(total_seconds) {
		  function pretty_time_string(num) {
			return ( num < 10 ? "0" : "" ) + num;
		  }

		  var hours = Math.floor(total_seconds / 3600);
		  total_seconds = total_seconds % 3600;

		  var minutes = Math.floor(total_seconds / 60);
		  total_seconds = total_seconds % 60;

		  var seconds = Math.floor(total_seconds);

		  // Pad the minutes and seconds with leading zeros, if required
		  hours = pretty_time_string(hours);
		  minutes = pretty_time_string(minutes);
		  seconds = pretty_time_string(seconds);

		  // Compose the string for display
		  var currentTimeString = new Array();
		  currentTimeString['current'] = hours + ":" + minutes + ":" + seconds;
		  currentTimeString['totalSeconds'] = parseInt(hours)*60*60 + parseInt(minutes)*60 + parseInt(seconds);	
		  return currentTimeString;
}

function setTime(){
	$.ajax({
		type:"POST",
		url:"http://coworkers-server.basok.su/api/setTime?auth=5dVsdksdVKeroolO2ZaergVDMnM",
		data:{'user_id':window.localStorage.getItem("user_id"), 'time':timeCurrent, 'date_start':date_start, 'date_end':date_end},
		dataType:"json",
		crossDomain: true,
		cache: false		
	});	
}

function playTime(){
	var today = new Date();
	date_start = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
	$.ajax({
		type:"POST",
		url:"http://coworkers-server.basok.su/api/playStopTime?auth=5dVsdksdVKeroolO2ZaergVDMnM",
		data:{'user_id':window.localStorage.getItem("user_id"), 'date_start':date_start, 'date_end':0, 'play':1},
		dataType:"json",
		crossDomain: true,
		cache: false
	});		
}
function stopTime(){
	var today = new Date();
	date_end = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
	$.ajax({
		type:"POST",
		url:"http://coworkers-server.basok.su/api/playStopTime?auth=5dVsdksdVKeroolO2ZaergVDMnM",
		data:{'user_id':window.localStorage.getItem("user_id"), 'date_end':date_end, 'play':0},
		dataType:"json",
		crossDomain: true,
		cache: false
	});	
}
$(function(){
	//$.removeCookie('page');
	
	/*$(window).scroll(function(){
		if($(window).scrollTop()>0 && $('.header').html()){
			$('.header').css('position','fixed');
			$('.content').css('margin-top','80px');
		}else{
			$('.header').css('position','relative');
			$('.content').css('margin-top','0');		
		}
	});*/
	
	page(window.localStorage.getItem("page"));
	
	if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
	 $('body').addClass('ios');
	}
	
	/*dash start*/
		
		
		$('html').on('click','.play',function(){
			$(this).addClass('stop').removeClass('play');
			if($('.circle .text').data('time')){
				split = $('.circle .text').data('time').split(':');
				time = parseInt(split[0])*60*60 + parseInt(split[1])*60 + parseInt(split[2]);
			}else{
				time=0;
			}
			timer(time);
			playTime();
			
			dateStart = $('.circle .text').data('start');
			if(dateStart==0){
				var today = new Date();
				if(date_start){
					old_date = date_start;
				}
				date_start = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
				if(old_date!=date_start){
					old_date = 0;
					timeCurrent = 0;
					date_start = 0;
					date_end = 0;					
				}
				$('.circle .text').data('start',date_start);
			}
		});
		
		$('html').on('click','.stop',function(){
			$(this).removeClass('stop').addClass('play');
			clearInterval(timerInterval);
			var today = new Date();
			date_end = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
			$('.circle .text').data('end',date_end);
			stopTime();
			page(window.localStorage.getItem("page"));			
		});				

		dashInterval = setInterval(function(){
			if(window.localStorage.getItem("page")=='dash'){
				page('dash');
			}
		},60000);
	/*dash end*/
	
	
	/*login start*/
	$('html').on('submit','.login-form form',function(){
		if(required()==true){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					$(th).find('.msg').remove();
					if(data['error']){
						$(th).find('button').before('<div class="msg">'+data['error']+'</div>');
					}else{
						window.localStorage.setItem("page", "dash");
						if(data['id']) window.localStorage.setItem("user_id", data['id']);
						if(data['user']) window.localStorage.setItem("username", data['user']);
						if(data['top_text']) window.localStorage.setItem("top_text", data['top_text']);
						page('dash');
					}
					$(window).scrollTop(0);
				}				
			});
		}			
		return false;
	});			
	/*login end*/
	
	/*registration start*/
		$('html').on('submit','.registration-send form',function(){
			if(required()){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){		
					$(th).find('.msg').remove();
					$('.im').remove();
					if(data['error']){	
						$('input[type="email"]').addClass('red');		
						$('input[type="email"]').after('<div class="im">'+data['error']+'</div>');						
					}else{
						window.localStorage.clear();
						page('login');
						setTimeout(function(){
							$('.content').prepend('<div class="success"><div class="wrapper">נרשמת בהצלחה!</div></div>');
							$('.success').fadeIn('slow');
							setTimeout(function(){$('.success').fadeOut('slow');},5000);
						},500);	
						$(window).scrollTop(0);	
					}
					
				}				
			});
			}			
			return false;
		});		
	/*registration end*/
	
	/*forgot start*/
		$forgot = {
			form1:function(){
				th = $('.form1');
				if(required('.form1')){				
					$.ajax({
						type:th.attr('method'),
						url:th.attr('action'),
						data:th.serialize(),
						dataType:"json",
						crossDomain: true,
						cache: false,
						success:function(data){		
							$(th).find('.msg').remove();
							$('.im').remove();
							if(data['error']){	
								$('input[type="email"]').addClass('red');		
								$('input[type="email"]').after('<div class="im">'+data['error']+'</div>');						
							}else{
								$('.form').css('display','none');
								$('.form2').css('display','block');
								$('.form2 input[name="email"]').val($('.form1 input[name="email"]').val());
								$('.content').prepend('<div class="success"><div class="wrapper">בדוק את הדואר שלך והקלד כאן את קוד ההפעלה</div></div>');
								$('.success').fadeIn('slow');								
							}
							
						}				
					});
				}			
				return false;
			},
			form2:function(){
				th = $('.form2');
				if(required('.form2')){
					$.ajax({
						type:th.attr('method'),
						url:th.attr('action'),
						data:th.serialize(),
						dataType:"json",
						crossDomain: true,
						cache: false,
						success:function(data){
							$('.success').remove();
							window.localStorage.clear();
							page('login');
							setTimeout(function(){
								$('.success').remove();
								$('.content').prepend('<div class="success"><div class="wrapper">נרשמת בהצלחה!</div></div>');
								$('.success').fadeIn('slow');
								setTimeout(function(){$('.success').fadeOut('slow');},5000);
							},500);	
							$(window).scrollTop(0);	
						}				
					});
				}			
				return false;
			}			
		}
	/*forgot end*/	
	
	/*forms start*/
		$('html').on('click','.form-user-tabs a',function(e){
			e.preventDefault;

			$('.form-user-tabs a').removeClass('active');
			$(this).addClass('active');	
			var value = $(this).text();
			$('input[name="type"]').val(value);
			
			if(value=='אלמנטרי'){
				$('input[name="fields[3][value]"]').removeClass('required');
				$('input[name="fields[3][value]"]').parent().css('display','none');
			}else{
				$('input[name="fields[3][value]"]').addClass('required');
				$('input[name="fields[3][value]"]').parent().css('display','block');			
			}
			return false;
		});
		
		$('html').on('submit','.form-send form',function(){
			if(required()){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					if(data){
						page('dash');
						setTimeout(function(){
							$('.success').remove();
							$('.content').prepend('<div class="success"><div class="wrapper">בקשתך נשלחה בהצלחה</div></div>');
							$('.success').fadeIn('slow');
							setTimeout(function(){$('.success').fadeOut('slow');},5000);
						},500);
					}
					$(window).scrollTop(0);
				}				
			});
			}			
			return false;
		});	

		$('html').on('submit','.filter form',function(){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
						if(data){
							html = '';
							$.each(data, function(i,v){
								$.each(v, function(i,v){
									if(i+1!=data.length && v.value.w==1){
										if(v.date) html += '<div class="head">החל מ '+v.date+'</div>';
									}	
									if(v.value.date_start && v.value.date_end && v.value.time){
										html += '<div class="item">';
										html += '<div class="day">'+month[v.value.w]+'</div>';	
										html += '<div class="date_start">'+v.value.date_start+'</div>';	
										html += '<div class="date_end">'+v.value.date_end+'</div>';
										html += '<div class="time">'+v.value.time+'</div>';
										html += '<div class="clear"></div>';
										html += '</div>';
									}
									if(v.value.w==7){
										html += '</div>'
									}
								});
							});
							$('#items').html(html);
						}
				}				
			});
						
			return false;
		});			
	/*forms end*/

	/* settings start*/
		$('html').on('submit','.settings-send form',function(){
			if(required()){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					console.log(data.errors);
					$('input').removeClass('red');
					if(!data.errors){
						page('dash');
						setTimeout(function(){
							$('.success').remove();
							$('.content').prepend('<div class="success"><div class="wrapper">ההגדרות נשמרו</div></div>');
							$('.success').fadeIn('slow');
							setTimeout(function(){$('.success').fadeOut('slow');},5000);
						},50);
					}else{
						
						$.each(data.errors,function(i,v){
							console.log(i+":::"+v);
							$('input[name="'+i+'"]').addClass('red');
						});
						
					}
					$(window).scrollTop(0);
				}				
			});
			}			
			return false;
		});		
	
	/* settings end */
	
	/*chat start*/
		checkMess();
		setInterval(checkMess,5000);

		$('html').on('click','.chat_send button',function(e){
			val = jQuery("#inp-send").val();
			if(val){
				sendMess(val);
			}
		});
		
		$(window).resize(function(){
			$('#chat').css('height',parseInt($(window).height())-parseInt($('.header').height())-parseInt($('#menu').height())+'px');
		});

		$(document).on('keypress',function(e) {
			if(e.which == 13) {
				val = jQuery("#inp-send").val();
				if(val){
					sendMess(val);
				}
			}
		});		
	/* chat end*/
	
	/*menu start*/
	
	$('html').on('click','#menu li a, a.btn, a.link , #back a',function(e){
		e.preventDefault;
		href = $(this).attr('href');
		page(href);
		$(window).scrollTop(0);
		return false;
	});	
	/*menu end*/
        jQuery(".fancybox").fancybox({
            openEffect	: 'elastic',
            closeEffect	: 'elastic',
			'width'         : 500,
			'height'		: 450,
			'autoSize' : false			
        });
		
});

function required(th=''){
	var ret = true;
	var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	$('.im').remove()
	$(th+' .required').each(function(){
		if($(this).val()=='' && $(this).attr('type')!='email' && $(this).attr('type')!='password'){
			$(this).addClass('red');
			ret = false;
		}else if(!regex.test($(this).val()) && $(this).attr('type')=='email'){
			$(this).addClass('red');
			ret = false;			
			$(this).parent().append('<div class="im">דוא"ל לא חוקי</div>');
		}else if($(this).val().length<5 && $(this).attr('type')=='password'){
			$(this).addClass('red');
			ret = false;			
			$(this).parent().append('<div class="im">מינימום 5 תווים</div>');
		}else if($(this).attr('name')=='re-password' && $(this).val()!=$('input[name="password"]').val()){
			$(this).addClass('red');
			ret = false;		
			$(this).parent().append('<div class="im">הסיסמאות שלך אינן תואמות</div>');
		}else{
			$(this).removeClass('red');
		}		
	});
	if(ret==true){
		return true;
	}else{
		$(window).scrollTop(0);
		return false;		
	}
}

function timedatehead(){	
		var today = new Date();
		var time = today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes() ;	
		var date = ('0' + today.getDate()).slice(-2) + "." + 	('0' + (today.getMonth()+1)).slice(-2) + "."+ today.getFullYear();	

		$('.header .time').text(time);
		$('.header .calendar').text(date);	
}

function getObjects(obj, key, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getObjects(obj[i], key, val));
        } else if (i == key && obj[key] == val) {
            objects.push(obj);
        }
    }
    return objects;
}

function page(page){
	$('#menu ul li a').removeClass('active');
	clearInterval(chatInterval);
	
	switch(page){
		case "registration":
			$('body').load('pages/registration.html');	
			window.localStorage.setItem("page", "registration");			
		break;	
		case "forgot":
			$('body').load('pages/forgot.html');	
			window.localStorage.setItem("page", "forgot");			
		break;			
		case "login":
			$('body').load('pages/login.html');
			window.localStorage.setItem("page", "login");			
		break;
		case "dash":	
			$('body').load('pages/dash.html', function(){
				$('#menu ul li a[href="dash"]').addClass('active');
				timedatehead();
				setInterval(function(){
					if($('.header .time').html()){
					timedatehead();
					}else{
						clearInterval(timedatehead);
					}
				},5000);
				var today = new Date();
				date_cur = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
				$.ajax({
					type:"POST",
					url:"http://coworkers-server.basok.su/api/dash?auth=5dVsdksdVKeroolO2ZaergVDMnM",
					data:{'user_id':window.localStorage.getItem("user_id"), 'date_cur':date_cur},
					dataType:"json",
					crossDomain: true,
					cache: false,			
					success:function(data){
				
						//console.log(data);
						if(data.timer.time){
							//getTime = get_elapsed_time_string(data.timer.time);
							$('.circle .text').text(data.timer.time);
							$('.circle .text').data('time',data.timer.time);
							timeCurrent = data.timer.time;						
						}
						
						if(data.timer.date_start){
							$('.circle .text').data('start',data.timer.date_start);
							date_start = data.timer.date_start;
						}
						
						if(data.timer.date_end){
							$('.circle .text').data('end',data.timer.date_end);
							date_end = data.timer.date_end;
						}
						
						if(data.timer.play==1){
							if($('.circle .text').data('time')){
								split = $('.circle .text').data('time').split(':');
								time = parseInt(split[0])*60*60 + parseInt(split[1])*60 + parseInt(split[2]);
							}else{
								time=0;
							}
							timer(time);							
						}
						
						today = new Date();
						if(data.holidays){
							
							cur_date = today.getFullYear()+'-'+('0' + (today.getMonth()+1)).slice(-2)+'-'+('0' + today.getDate()).slice(-2);		
							if(getObjects(data.holidays,cur_date,cur_date).length>0) {								
								$('.circle').html('<div class="t">חג לאומי</div>');
							}
						}
						
						if(data.days){
							day = today.getDay();
							if(!data.days[day]){
								$('.circle').html('<div class="t">יום חופש</div>');
							}
						}
					
						if(data.timer.type==2){
							$('.circle').html('<div class="t">חופשה</div>');
						}

						if(data.timer.type==3){
							$('.circle').html('<div class="t">חופשת מחלה</div>');
						}						

						if(data.dates){
							html = '';
							$.each(data.dates, function(i,v){
								$.each(v, function(i,v){
									if(i+1!=data.dates.length && v.value.w==1){
										if(v.date) html += '<div class="head">החל מ '+v.date+'</div>';
									}	
									if(v.value.date_start && v.value.date_end && v.value.time){
										html += '<div class="item">';
										html += '<div class="day">'+month[v.value.w]+'</div>';	
										if(v.value.type==0) html += '<div class="date_start">'+v.value.date_start+'</div>';	
										if(v.value.type==0) html += '<div class="date_end">'+v.value.date_end+'</div>';
										if(v.value.type==0){
											html += '<div class="time">'+v.value.time+'</div>';
										}else{
											
											html += '<div class="time">'+reason[v.value.type]+'</div>';
										}
										html += '<div class="clear"></div>';
										html += '</div>';
									}
									if(v.value.w==7){
										html += '</div>'
									}
								});
							});
							$('#items').html(html);
						}
					}		
				});

				window.localStorage.setItem("page", "dash");
			});		
		break;
		case "items":
			$('body').load('pages/items.html', function(){
				$('#menu ul li a[href="items"]').addClass('active');
				$(".date" ).datepicker({dateFormat: 'dd.mm.yy'});
				$('body').attr('class','items');

				$('input[name="user_id"]').val(window.localStorage.getItem("user_id"));
				$.ajax({
					type:"POST",
					url:"http://coworkers-server.basok.su/api/getForms?auth=5dVsdksdVKeroolO2ZaergVDMnM",
					data:{'user_id':window.localStorage.getItem("user_id")},
					dataType:"json",
					crossDomain: true,
					cache: false,			
					success:function(data){
						if(data){
							html = '';
							$.each(data, function(i,v){
								$.each(v, function(i,v){
									if(i+1!=data.length && v.value.w==1){
										if(v.date) html += '<div class="head">החל מ '+v.date+'</div>';
									}	
									if(v.value.date_start && v.value.date_end && v.value.time){
										html += '<div class="item">';
										html += '<div class="day">'+month[v.value.w]+'</div>';	
										if(v.value.type==0) html += '<div class="date_start">'+v.value.date_start+'</div>';	
										if(v.value.type==0) html += '<div class="date_end">'+v.value.date_end+'</div>';
										if(v.value.type==0){
											html += '<div class="time">'+v.value.time+'</div>';
										}else{
											
											html += '<div class="time">'+reason[v.value.type]+'</div>';
										}
										html += '<div class="clear"></div>';
										html += '</div>';
									}
									if(v.value.w==7){
										html += '</div>'
									}
								});
							});
							$('#items').html(html);
						}						
					}		
				});	
				window.localStorage.setItem("page", "items");
			});
						
		break;		
		case "settings":
			$('body').load('pages/settings.html', function(){
				$('#menu ul li a[href="settings"]').addClass('active');
				$.ajax({
					type:"POST",
					url:"http://coworkers-server.basok.su/api/getProfile?auth=5dVsdksdVKeroolO2ZaergVDMnM",
					data:{'user_id':window.localStorage.getItem("user_id")},
					dataType:"json",
					crossDomain: true,
					cache: false,			
					success:function(data){
						if(data.email) $('input[name="email"]').val(data.email);
						if(data.user) $('input[name="user"]').val(data.user);
						$('body').attr('class','settings');	
						$('input[name="user_id"]').val(window.localStorage.getItem("user_id"));
						
						$('input[name="password"]').keyup(function(){
							val = $(this).val().length;
							if(val>0){
								$('input[name="password"]').addClass('required');
								$('input[name="re-password"]').addClass('required');
							}else{
								$('input[name="password"]').removeClass('required');
								$('input[name="re-password"]').removeClass('required');
							}
						});
					}
				});
					
			});
			window.localStorage.setItem("page", "settings");			
		break;
		case "chat":
			$('body').load('pages/chat.html', function(){
				$('#menu ul li a[href="chat"]').addClass('active');
				scroll=0;
				clearInterval(chatInterval);
				getChat();
				chatInterval = setInterval(getChat, 5000);
				window.localStorage.setItem("page", "chat");
			});
						
		break;			
		case "logout":
			 window.localStorage.clear();
			$('body').load('pages/login.html');	
		break;				
		default:
			window.localStorage.clear();
			$('body').load('pages/first.html');						
	}	
	$(window).scrollTop(0);
}

function getChat(){
		$.ajax({
			type:"POST",
			url:"http://coworkers-server.basok.su/api/getChat?auth=5dVsdksdVKeroolO2ZaergVDMnM",
			data:{'id':window.localStorage.getItem("user_id")},
			dataType:"json",
			success:function(data){
				html = '';
				if(data){
					$.each(data,function(i,v){
						var you = '';
						if(v.from==window.localStorage.getItem("user_id")){
							you = 'you';
						}
						html +="<div class='row'><div class='mes "+you+"'><div class='date'>"+v.date+"</div>"+v.message+"</div></div>";
						
					});					
				}
				$('#chat').css('height',parseInt($(window).height())-parseInt($('.header').height())-parseInt($('#menu').height())+'px');
				$('#chat .chat_body').html(html);
				if(!scroll){
					scrollHeight = $("#chat .chat_body .row").length*($("#chat .chat_body .row").height()+10);
					$("#chat .chat_body").animate({ scrollTop: scrollHeight}, 1000);
				}
				scroll=1;
			}		
		});	
}

function checkMess(){		
		$.ajax({
			type:"POST",
			url:"http://coworkers-server.basok.su/api/getUnread?auth=5dVsdksdVKeroolO2ZaergVDMnM",
			data:{'id':window.localStorage.getItem("user_id")},
			dataType:"json",
			success:function(data){
				$('#menu ul li a[href="chat"] .unread').remove();
				if(data!=0){
					$('#menu ul li a[href="chat"]').prepend('<span class="unread">'+data+'</span>');	
				}
			}		
		});
}

function sendMess(val){
		$.ajax({
			type:"POST",
			url:"http://coworkers-server.basok.su/api/sendChat?auth=5dVsdksdVKeroolO2ZaergVDMnM",
			data:{'id':3, 'from':window.localStorage.getItem("user_id"), 'message':val},
			dataType:"json",
			success:function(){
				$("#inp-send").val('');
				scroll=0;
				clearInterval(chatInterval);
				getChat();
				chatInterval = setInterval(getChat, 5000);
			}		
		});	
}