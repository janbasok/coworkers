var timerInterval = 0;
var timeCurrent = 0;
var date_start = 0;
var date_end = 0;
//cordova.plugins.backgroundMode.enable();
function get_elapsed_time_string(total_seconds) {
		  function pretty_time_string(num) {
			return ( num < 10 ? "0" : "" ) + num;
		  }

		  var hours = Math.floor(total_seconds / 3600);
		  total_seconds = total_seconds % 3600;

		  var minutes = Math.floor(total_seconds / 60);
		  total_seconds = total_seconds % 60;

		  var seconds = Math.floor(total_seconds);

		  // Pad the minutes and seconds with leading zeros, if required
		  hours = pretty_time_string(hours);
		  minutes = pretty_time_string(minutes);
		  seconds = pretty_time_string(seconds);

		  // Compose the string for display
		  var currentTimeString = new Array();
		  currentTimeString['current'] = hours + ":" + minutes + ":" + seconds;
		  currentTimeString['totalSeconds'] = parseInt(hours)*60*60 + parseInt(minutes)*60 + parseInt(seconds);	
		  return currentTimeString;
}

function setTime(){
	$.ajax({
		type:"POST",
		url:"http://coworkers-server.basok.ga/api/setTime?auth=5dVsdksdVKeroolO2ZaergVDMnM",
		data:{'user_id':window.localStorage.getItem("user_id"), 'time':timeCurrent, 'date_start':date_start, 'date_end':date_end},
		dataType:"json",
		crossDomain: true,
		cache: false		
	});	
}
$(function(){
	//$.removeCookie('page');
	
	/*$(window).scroll(function(){
		if($(window).scrollTop()>0 && $('.header').html()){
			$('.header').css('position','fixed');
			$('.content').css('margin-top','80px');
		}else{
			$('.header').css('position','relative');
			$('.content').css('margin-top','0');		
		}
	});*/
	
	page(window.localStorage.getItem("page"));
	
	if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
	 $('body').addClass('ios');
	}
	
	/*dash start*/
		
		
		$('html').on('click','.play',function(){
			$(this).addClass('stop').removeClass('play');
			timer($('.circle .text').data('time'));
			
			dateStart = $('.circle .text').data('start');
			if(dateStart==0){
				var today = new Date();
				date_start = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
				$('.circle .text').data('start',date_start);
			}	
		});
		
		$('html').on('click','.stop',function(){
			$(this).removeClass('stop').addClass('play');
			clearInterval(timerInterval);
			var today = new Date();
			date_end = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate()+' '+today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes()+ ":" +today.getSeconds();	
			$('.circle .text').data('end',date_end);
			setTime();			
		});				

		function timer(elapsed_seconds){
			timerInterval = setInterval(function() {
			  elapsed_seconds = elapsed_seconds + 1;
			  getTime = get_elapsed_time_string(elapsed_seconds);
			  $('.circle .text').text(getTime['current']);
			  $('.circle .text').data('time',getTime['totalSeconds']);
			  timeCurrent = getTime['totalSeconds'];
			  $('.play').addClass('stop').removeClass('play');
			  setTime();
			}, 1000);
		}	
	/*dash end*/
	
	
	/*login start*/
	$('html').on('submit','.login-form form',function(){
		if(required()==true){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					$(th).find('.msg').remove();
					if(data['error']){
						$(th).find('button').before('<div class="msg">'+data['error']+'</div>');
					}else{
						window.localStorage.setItem("page", "dash");
						if(data['id']) window.localStorage.setItem("user_id", data['id']);
						if(data['user']) window.localStorage.setItem("username", data['user']);
						if(data['top_text']) window.localStorage.setItem("top_text", data['top_text']);
						page('dash');
					}
					$(window).scrollTop(0);
				}				
			});
		}			
		return false;
	});			
	/*login end*/
	
	/*registration start*/
		$('html').on('submit','.registration-send form',function(){
			if(required()){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){		
					$(th).find('.msg').remove();
					$('.im').remove();
					if(data['error']){	
						$('input[type="email"]').addClass('red');		
						$('input[type="email"]').after('<div class="im">'+data['error']+'</div>');						
					}else{
						window.localStorage.clear();
						page('login');
						setTimeout(function(){
							$('.content').prepend('<div class="success"><div class="wrapper">נרשמת בהצלחה!</div></div>');
							$('.success').fadeIn('slow');
							setTimeout(function(){$('.success').fadeOut('slow');},5000);
						},500);	
						$(window).scrollTop(0);	
					}
					
				}				
			});
			}			
			return false;
		});		
	/*registration end*/
	
	/*forgot start*/
		$forgot = {
			form1:function(){
				th = $('.form1');
				if(required('.form1')){				
					$.ajax({
						type:th.attr('method'),
						url:th.attr('action'),
						data:th.serialize(),
						dataType:"json",
						crossDomain: true,
						cache: false,
						success:function(data){		
							$(th).find('.msg').remove();
							$('.im').remove();
							if(data['error']){	
								$('input[type="email"]').addClass('red');		
								$('input[type="email"]').after('<div class="im">'+data['error']+'</div>');						
							}else{
								$('.form').css('display','none');
								$('.form2').css('display','block');
								$('.form2 input[name="email"]').val($('.form1 input[name="email"]').val());
								$('.content').prepend('<div class="success"><div class="wrapper">בדוק את הדואר שלך והקלד כאן את קוד ההפעלה</div></div>');
								$('.success').fadeIn('slow');								
							}
							
						}				
					});
				}			
				return false;
			},
			form2:function(){
				th = $('.form2');
				if(required('.form2')){
					$.ajax({
						type:th.attr('method'),
						url:th.attr('action'),
						data:th.serialize(),
						dataType:"json",
						crossDomain: true,
						cache: false,
						success:function(data){
							$('.success').remove();
							window.localStorage.clear();
							page('login');
							setTimeout(function(){
								$('.content').prepend('<div class="success"><div class="wrapper">נרשמת בהצלחה!</div></div>');
								$('.success').fadeIn('slow');
								setTimeout(function(){$('.success').fadeOut('slow');},5000);
							},500);	
							$(window).scrollTop(0);	
						}				
					});
				}			
				return false;
			}			
		}
	/*forgot end*/	
	
	/*forms start*/
		$('html').on('click','.form-user-tabs a',function(e){
			e.preventDefault;

			$('.form-user-tabs a').removeClass('active');
			$(this).addClass('active');	
			var value = $(this).text();
			$('input[name="type"]').val(value);
			
			if(value=='אלמנטרי'){
				$('input[name="fields[3][value]"]').removeClass('required');
				$('input[name="fields[3][value]"]').parent().css('display','none');
			}else{
				$('input[name="fields[3][value]"]').addClass('required');
				$('input[name="fields[3][value]"]').parent().css('display','block');			
			}
			return false;
		});
		
		$('html').on('submit','.form-send form',function(){
			if(required()){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					if(data){
						page('items');
						setTimeout(function(){
							$('.content').prepend('<div class="success"><div class="wrapper">בקשתך נשלחה בהצלחה</div></div>');
							$('.success').fadeIn('slow');
							setTimeout(function(){$('.success').fadeOut('slow');},5000);
						},500);
					}
					$(window).scrollTop(0);
				}				
			});
			}			
			return false;
		});	

		$('html').on('submit','.filter form',function(){
			th = $(this);
			$.ajax({
				type:th.attr('method'),
				url:th.attr('action'),
				data:th.serialize(),
				dataType:"json",
				crossDomain: true,
				cache: false,
				success:function(data){
					if(data){
						var html = '';
						$.each(data, function(index,value){
							if(value.status==1){
								cl="green";
							}else{
								cl="";
							}							
							html += '<tr href="#form-'+value.id+'" class="fancybox '+cl+'">';
							html += '<td>';
							html += '<div id="form-'+value.id+'" class="popup">';
							html += '<div class="row tit">#'+value.id+' '+value.type+'</div>';
							if(value.fields){
								$.each(value.fields, function(index,field){	
									html += '<div class="row">'+field.title+': '+field.value+'</div>';
								});
							}
							html += '</div>';
							html += value.user+'</td>';
							html += '<td>'+value.date+'</td>';
							html += '<td>'+value.status+'</td>';
							html += '</tr>';
						});
						$('.leads table tbody').html(html);
						$(window).scrollTop(0);
					}
				}				
			});
						
			return false;
		});			
	/*forms end*/	
	
	/*menu start*/
	
	$('html').on('click','#menu li a, a.btn, a.link , #back a',function(e){
		e.preventDefault;
		href = $(this).attr('href');
		page(href);
		$(window).scrollTop(0);
		return false;
	});	
	/*menu end*/
        jQuery(".fancybox").fancybox({
            openEffect	: 'elastic',
            closeEffect	: 'elastic',
			'width'         : 500,
			'height'		: 450,
			'autoSize' : false			
        });
		
});

function required(th=''){
	var ret = true;
	var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	$('.im').remove()
	$(th+' .required').each(function(){
		if($(this).val()=='' && $(this).attr('type')!='email' && $(this).attr('type')!='password'){
			$(this).addClass('red');
			ret = false;
		}else if(!regex.test($(this).val()) && $(this).attr('type')=='email'){
			$(this).addClass('red');
			ret = false;			
			$(this).parent().append('<div class="im">דוא"ל לא חוקי</div>');
		}else if($(this).val().length<5 && $(this).attr('type')=='password'){
			$(this).addClass('red');
			ret = false;			
			$(this).parent().append('<div class="im">מינימום 5 תווים</div>');
		}else if($(this).attr('name')=='re-password' && $(this).val()!=$('input[name="password"]').val()){
			$(this).addClass('red');
			ret = false;		
			$(this).parent().append('<div class="im">הסיסמאות שלך אינן תואמות</div>');
		}else{
			$(this).removeClass('red');
		}		
	});
	if(ret==true){
		return true;
	}else{
		$(window).scrollTop(0);
		return false;		
	}
}

function timedatehead(){	
		var today = new Date();
		var time = today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes() ;	
		var date = today.getDate() + "." + (today.getMonth()+1) + "."+ today.getFullYear();	
		$('.header .time').text(time);
		$('.header .calendar').text(date);	
}

function page(page){
	$('#menu ul li a').removeClass('active');
	switch(page){
		case "registration":
			$('body').load('pages/registration.html');	
			window.localStorage.setItem("page", "registration");			
		break;	
		case "forgot":
			$('body').load('pages/forgot.html');	
			window.localStorage.setItem("page", "forgot");			
		break;			
		case "login":
			$('body').load('pages/login.html');
			window.localStorage.setItem("page", "login");			
		break;
		case "dash":	
			$('body').load('pages/dash.html', function(){
				$('#menu ul li a[href="dash"]').addClass('active');
				timedatehead();
				setInterval(function(){
					if($('.header .time').html()){
					timedatehead();
					}else{
						clearInterval(timedatehead);
					}
				},5000);
				$.ajax({
					type:"POST",
					url:"http://coworkers-server.basok.ga/api/dash?auth=5dVsdksdVKeroolO2ZaergVDMnM",
					data:{'user_id':window.localStorage.getItem("user_id")},
					dataType:"json",
					crossDomain: true,
					cache: false,			
					success:function(data){
						if(timeCurrent){
						  getTime = get_elapsed_time_string(timeCurrent);
						  $('.circle .text').text(getTime['current']);
						  $('.circle .text').data('time',getTime['totalSeconds']);						  
						}else if(data.timer.time){
							getTime = get_elapsed_time_string(data.timer.time);
							$('.circle .text').text(getTime['current']);
							$('.circle .text').data('time',getTime['totalSeconds']);
							timeCurrent = data.timer.time;						
						}
						
						if(date_start){
							$('.circle .text').data('start',date_start);
						}else if(data.timer.date_start){
							$('.circle .text').data('start',data.timer.date_start);
							date_start = data.timer.date_start;
						}
						
						if(date_end){
							$('.circle .text').data('end',date_end);
						}else if(data.timer.date_end){
							$('.circle .text').data('end',data.timer.date_end);
							date_end = data.timer.date_end;
						}						
					}		
				});
				
				window.localStorage.setItem("page", "dash");
			});		
		break;
		case "items":
			$('body').load('pages/items.html', function(){
				$('#menu ul li a[href="items"]').addClass('active');
				$( ".date" ).datepicker({ dateFormat: 'dd.mm.yy' });
				$('input[name="user_id"]').val(window.localStorage.getItem("user_id"));
				$.ajax({
					type:"POST",
					url:"http://coworkers-server.basok.ga/api/getForms?auth=5dVsdksdVKeroolO2ZaergVDMnM",
					data:{'user_id':window.localStorage.getItem("user_id")},
					dataType:"json",
					crossDomain: true,
					cache: false,			
					success:function(data){
						if(data){
							var html = '';
							$.each(data, function(index,value){	
								if(value.status==1){
									cl="green";
								}else{
									cl="";
								}
								html += '<tr class="'+cl+'">';
								html += '<td>';
								html += '<div id="form-'+value.id+'" class="popup">';
								html += '<div class="row tit">#'+value.id+' '+value.type+'</div>';
								if(value.fields){
									$.each(value.fields, function(index,field){	
										html += '<div class="row">'+field.title+': '+field.value+'</div>';
									});
								}
								html += '</div>';
								html += '<a href="#form-'+value.id+'" class="fancybox">'+value.user+'</a></td>';
								html += '<td><a href="#form-'+value.id+'" class="fancybox">'+value.date+'</a></td>';
								html += '<td>'+value.status+'</td>';
								html += '</tr>';
								
							});
							$('.leads table tbody').html(html);
						}						
					}		
				});	
				window.localStorage.setItem("page", "items");
			});
						
		break;		
		case "form":
			$('body').load('pages/form.html', function(){
				var value = $('.form-user-tabs a.active').text();
				$('input[name="type"]').val(value);
				$('input[name="user_id"]').val(window.localStorage.getItem("user_id"));
			});
			window.localStorage.setItem("page", "form");			
		break;
		case "logout":
			 window.localStorage.clear();
			$('body').load('pages/login.html');	
		break;				
		default:
			window.localStorage.clear();
			$('body').load('pages/first.html');						
	}	
	$(window).scrollTop(0);
}