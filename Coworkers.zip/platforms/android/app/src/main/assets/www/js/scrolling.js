function scrolling(count,general,inside, nav){
	general = nav+' '+general;
	inside = nav+' '+inside;
	//console.log($(general).width());
	//$(general).css('width',parseInt($(nav).css('width'))+25+'px');
	margin_left = parseInt($(inside+'>div').css('margin-left'));
	margin_right = parseInt($(inside+'>div').css('margin-right'));
	if($(window).width()>=1024){ 
		var stepSize2 = parseFloat($(general).width())/3;
	}else if($(window).width()<1024 && $(window).width()>400){
		var stepSize2 = parseFloat($(general).width())/2;
	}else if($(window).width()<400){
		var stepSize2 = parseFloat($(general).width())/1;
	}
	//console.log(margin_left);
	stepSize2 = stepSize2-margin_left-margin_right;
    var container = $(general);
   // var content = container.find(inside);
	var margin = margin_left*count + margin_right*count;
	$(inside+'>div').css('width',stepSize2);
	item = count-1;
	//$(inside+'>div:eq('+item+')').css('margin-left',0);
	$(inside).css('width',count*stepSize2+margin+'px');
	

    function scroll(offset) {
		container.animate({"scrollLeft":container.scrollLeft() + offset},300, function(){
			container.stop(true);
		});	
    }

    $('.left', nav).bind('click', function() {
		if(parseInt(container.scrollLeft())==0){
			scroll((count*(stepSize2+margin_left)-margin_left));
		}else{
			if(container.scrollLeft()!=1){
				scroll(0 - (stepSize2+margin_left+margin_right));
			}
		}		

    });
    $('.right', nav).bind('click', function() {	
	var maxScrollLeft = container[0].scrollWidth - container[0].clientWidth;
	console.log(maxScrollLeft);
	console.log(parseInt(container.scrollLeft()));
		if(parseInt(maxScrollLeft)==parseInt(container.scrollLeft()) || (parseInt(maxScrollLeft)-1==parseInt(container.scrollLeft())) || (parseInt(maxScrollLeft)-2==parseInt(container.scrollLeft())) || (parseInt(maxScrollLeft)-3==parseInt(container.scrollLeft())) || (parseInt(maxScrollLeft)-4==parseInt(container.scrollLeft())) || (parseInt(maxScrollLeft)-5==parseInt(container.scrollLeft()))){
			scroll(0-(count*(stepSize2+margin_left)-margin_left));
		}else{
			scroll(stepSize2+margin_left+margin_right);
		}

    });
	
	
	if(count < 4){
		$('.left', nav).remove();
		$('.right', nav).remove();
	}
		
};

function scrolling2(count,general,inside, nav){
	if(count < 5){
		$('.left', nav).remove();
		$('.right', nav).remove();
	}	
	general = nav+' '+general;
	inside = nav+' '+inside;
	//$(general).css('width',parseInt($(nav).css('width'))+25+'px');
	var margin_left = parseFloat($(inside+'>div').css('margin-left'));
	var margin_right = parseFloat($(inside+'>div').css('margin-right'));
	if($(window).width()>1024){ 
		var stepSize = (parseFloat($(nav).width())-parseFloat($(nav).width())/100*4)/4;
	}else if($(window).width()<=1024 && $(window).width()>640){
		var stepSize = (parseFloat($(nav).width())-parseFloat($(nav).width())/100*4)/3;
	}else if($(window).width()<=640 && $(window).width()>480){
		var stepSize = (parseFloat($(nav).width())-parseFloat($(nav).width())/100*4)/2;
	}else if($(window).width()<=480){
		var stepSize = (parseFloat($(nav).width())-parseFloat($(nav).width())/100*4);
	}
	//console.log(margin_left);
	var countW = (parseFloat($(nav).width())-parseFloat($(nav).width())/100*4)/stepSize; 
	stepSize = stepSize-margin_left-margin_right;
    var container = $(general);
   // var content = container.find(inside);
  
	var margin = margin_left*count + margin_right*count;
	/*console.log(count*stepSize);
	console.log(margin);*/
	$(inside+'>div').css('width',stepSize);
	item = count-1;
	$(inside+'>div:eq('+item+')').css('margin-left',0);
	$(inside).css('width',((count*stepSize)+margin)+'px');
	
	//console.log(stepSize+margin_left);
	$(general).css('width',(countW*(stepSize+margin_left)-margin_left)+'px');

    function scroll(offset) {
		container.animate({"scrollLeft":container.scrollLeft() + offset},300, function(){
			container.stop(true);
		});	
    }

    $('.left', nav).bind('click', function() {		
		if(parseInt(container.scrollLeft())==0){
			scroll((countW*(stepSize+margin_left)-margin_left));
		}else{
			if(container.scrollLeft()!=1){
				scroll(0 - (stepSize+margin_left+margin_right));
			}
		}
    });
    $('.right', nav).bind('click', function() {
		if(parseInt(stepSize+margin_left+margin_right)<=parseInt(container.scrollLeft())){
			scroll(0-(countW*(stepSize+margin_left)-margin_left));
		}else{
			scroll(stepSize+margin_left+margin_right);
		}
    });
		
};