package com.transistorsoft.cordova.backgroundfetch;

import android.content.Context;

/**
 * Created by chris on 2018-01-22.
 */

public interface HeadlessTask {
    void onFetch(Context context);
}
